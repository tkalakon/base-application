package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FourthServletHidden")
public class FourthServletHidden extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city=request.getParameter("city");
		String state=request.getParameter("state");

		
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Fourth Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form name='fourthfrm' action='#' method='post'>");
		out.println("<tr>");
		out.println("<td>First Name:</td>"+firstName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Last Name:</td>"+lastName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<tr>");
		out.println("<td>City:</td>"+city);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>State:</td>"+state);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Phone:</td>"+phone);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Email:</td>"+email);
		out.println("<br></tr>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
}
