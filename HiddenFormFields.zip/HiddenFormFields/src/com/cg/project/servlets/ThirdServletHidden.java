package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ThirdServletHidden")
public class ThirdServletHidden extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		request.setAttribute("city", city);
		request.setAttribute("state",state);
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Third Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form name='thirdfrm' action='FourthServletHidden' method='post'>");
		out.println("<tr>");
		out.println("<td>First Name:</td>"+firstName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Last Name:</td>"+lastName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<tr>");
		out.println("<td>City:</td>"+city);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>State:</td>"+state);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Phone:</td>");
		out.println("<td><input type='text' name='phone'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>Email:</td>");
		out.println("<td><input type='text' name='email'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='firstName' value="+firstName+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='lastName' value="+lastName+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='city' value="+city+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='hidden' name='state' value="+state+"><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='submit' name='submit'></td>");
		out.println("</tr>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
}
