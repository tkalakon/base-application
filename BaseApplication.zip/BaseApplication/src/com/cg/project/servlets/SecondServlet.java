package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SecondServlet")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}
	public void destroy() {
		// TODO Auto-generated method stub
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Second Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form name='secondfrm' action='ThirdServlet' method='post'>");
		out.println("<tr>");
		out.println("<td>First Name:</td>"+firstName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>Last Name:</td>"+lastName);
		out.println("<br></tr>");
		out.println("<tr>");
		out.println("<td>City:</td>");
		out.println("<td><input type='text' name='city'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>State:</td>");
		out.println("<td><input type='text' name='state'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='submit' name='submit'></td>");
		out.println("</tr>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
