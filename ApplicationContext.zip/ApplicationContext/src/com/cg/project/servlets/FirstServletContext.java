package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FirstServletContext")
public class FirstServletContext extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}
	public void destroy() {
		// TODO Auto-generated method stub
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>First Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form name='firstfrm' action='SecondServletContext' method='post'>");
		out.println("<tr>");
		out.println("<td>First Name:</td>");
		out.println("<td><input type='text' name='firstName'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>Last Name:</td>");
		out.println("<td><input type='text' name='lastName'><br></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='submit' name='submit'></td>");
		out.println("</tr>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
}
